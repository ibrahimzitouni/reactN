import React , {useState} from 'react';
import { Text, View, StyleSheet, Alert } from 'react-native';
import Xbutton from './compo/XButton';
import calculate from './compo/calculate';

export default function App() {
  const [text , setText] = useState('0') ;
  const pressHandler = (val) => {
    setText(calculate(val));
  }
  return (
    <View style={styles.all}>
      <View style={styles.result}>
        <Text style={styles.resulttext} >{text}</Text>
      </View>
      <View style={styles.bottom}>
         <View style={styles.myrow}>
        <Xbutton style={styles.button} TextStyle={styles.TextStyle} onclick={() => pressHandler('C')} >C</Xbutton>
        <Xbutton style={styles.button} TextStyle={styles.TextStyle} onclick={() => pressHandler('%')} >%</Xbutton>
        <Xbutton style={styles.button} TextStyle={styles.TextStyle} onclick={() => pressHandler('d')} >d</Xbutton>
        <Xbutton style={styles.button} TextStyle={styles.TextStyle} onclick={() => pressHandler('÷')} >÷</Xbutton>
</View>
<View style={styles.myrow}>
        <Xbutton style={styles.button} TextStyle={styles.TextStyle} onclick={() => pressHandler('1')} >1</Xbutton>
        <Xbutton style={styles.button} TextStyle={styles.TextStyle} onclick={() => pressHandler('2')} >2</Xbutton>
        <Xbutton style={styles.button} TextStyle={styles.TextStyle} onclick={() => pressHandler('3')} >3</Xbutton>
        <Xbutton style={styles.button} TextStyle={styles.TextStyle} onclick={() => pressHandler('-')} >-</Xbutton>
</View>
<View style={styles.myrow}>
        <Xbutton style={styles.button} TextStyle={styles.TextStyle} onclick={() => pressHandler('4')} >4</Xbutton>
        <Xbutton style={styles.button} TextStyle={styles.TextStyle} onclick={() => pressHandler('5')} >5</Xbutton>
        <Xbutton style={styles.button} TextStyle={styles.TextStyle} onclick={() => pressHandler('6')} >6</Xbutton>
        <Xbutton style={styles.button} TextStyle={styles.TextStyle} onclick={() => pressHandler('+')} >+</Xbutton>
</View>
<View style={styles.myrow}>
        <Xbutton style={styles.button} TextStyle={styles.TextStyle} onclick={() => pressHandler('7')} >7</Xbutton>
        <Xbutton style={styles.button} TextStyle={styles.TextStyle} onclick={() => pressHandler('8')} >8</Xbutton>
        <Xbutton style={styles.button} TextStyle={styles.TextStyle} onclick={() => pressHandler('9')} >9</Xbutton>
        <Xbutton style={styles.button} TextStyle={styles.TextStyle} onclick={() => pressHandler('x')} >x</Xbutton>
</View>
<View style={styles.myrow}>
        <Xbutton style={styles.button} TextStyle={styles.TextStyle} onclick={() => pressHandler('.')} >.</Xbutton>
        <Xbutton style={styles.button} TextStyle={styles.TextStyle} onclick={() => pressHandler('0')} >0</Xbutton>
        <Xbutton style={styles.dbbutton} TextStyle={styles.dbTextStyle} onclick={() => pressHandler('=')} >=</Xbutton>
</View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  all : {
    flex : 1
  },
  resulttext : {
    textAlign : 'right',
    fontSize : 50,
    color : "white",
    marginBottom : 20,
    marginRight : 10,
    
  },
  result : {
    borderColor : "black",
    borderWidth : 3,
    backgroundColor:'gray',
    justifyContent : 'flex-end',
    flex : 1
  } ,
  button : {
    borderWidth : 1,
    borderColor : "black",
    backgroundColor : "rgb(0,150,150)" ,
    flex : 1 , 
    
  },
  dbbutton : {
    borderWidth : 1,
    borderColor : "black",
    backgroundColor : "blue" ,
    flex : 2.04 , 
    
  },
  TextStyle : {
    fontSize : 36,
    color : "white",
    textAlign : 'center',
    marginTop : 10
  },
  dbTextStyle : {
    fontSize : 30,
    color : "white",
    paddingLeft : 80
  },
  myrow : {
    flexDirection : "row",
    flex : 1
  },
  bottom : {
    flex : 2
  }
});
