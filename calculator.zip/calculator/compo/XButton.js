import React , { Component } from 'react';
import { TouchableOpacity  , Text } from 'react-native';

const Xbutton = ({style , children , TextStyle , onclick }) => {
    return <TouchableOpacity style={style} onPress={onclick}>
            <Text style={TextStyle} >{children}</Text>
           </TouchableOpacity>
}
export default Xbutton ;