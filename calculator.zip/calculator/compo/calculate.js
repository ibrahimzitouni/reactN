import React from 'react';
let val ='' ;
const deleteLastItem = (x) => {
    return x.slice(0,x.length-1)
}
const calculate = (arg) => {
		if ( val.charAt(val.length-1) == '+' || val.charAt(val.length-1) == '-' || val.charAt(val.length-1) == 'x' ||val.charAt(val.length-1) == '÷' )
		{ 
			if ( arg == '+' || arg == '-' || arg == 'x' || arg == '÷' )
			{
				val = deleteLastItem(val)
			}
		}
		if ( val == '0' )
			val = ''
		if (arg == '=' || arg == 'C' || arg == '%' || arg == 'd')
		{
			if (arg == 'C')
			{
				val='0'
			}
			if (arg == '=')
			{
				val = val.replace('x','*')
				val = val.replace('÷','/')
				val = eval(val)
				val = val.toString()
			}
			if (arg == '%')
				val = eval(val+'/100')
			if (arg == 'd')
			{
				if (val.length <= 1 )
				{
					val = '0'
				}
				else 
				{
					val = val.replace(val.charAt(val.length-1),'')
				}
			}
		}
		else
		{
			val = val + arg ;
		}
return val.toString()
}
export default calculate ;